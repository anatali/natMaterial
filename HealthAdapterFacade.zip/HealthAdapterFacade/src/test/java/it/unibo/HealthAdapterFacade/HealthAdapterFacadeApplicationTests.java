package it.unibo.HealthAdapterFacade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthAdapterFacadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
