Each of the XML Files in this directory contains the "license terms" for a 
standard HL7 license in two xml name spaces.  The license types are:

EPL - 
  Eclipse Public License - For use with MIF-Lite files and non-annotated 
  XML schemas

HL7 - Propritary - 
  The implicity HL7 IP license that applies to HL7 members and that is 
  documented in the Bylaws.  Applies to FULL MIF files, annotated schemas 
  and other HL7 IP.

HL7 - ToolFile - 
  Is the "open" single-user license that restricts to activities supporting
  the development of and implementation of HL7 specifications. This license
  was PREVIOUSLY used for the HL7 schemas, but it is not clear that it is 
  needed for anything other than the HL7-developed Tools (RMIM Designer, V3
  Generator, V3-Generator Transforms and Build files, etc.)

Each file has:

root element named "mif:licenseHeader" that 
  has attribute "name" showing which License type
  has attribute "representationKind" with values of "MIF1" or "MIF2"
  has xmlns declaration of the prefix "mif:" for either MIF1 or MIF2

mif:licenseHeader element holds one or two "mif:header" elements with a 
  single "mif:legalese" element.  The licenseHeader elements in the 
  MIF2 files hold representatioonKind attributes of MIF2 and MIF215 for
  dual and single namespace markup.

mif:legalese has two attributes "copyrightOwner" (Health Level Seven) and 
  "copyrightYears" (2009).  It also has two elements:

mif:legalese/mif:notation simply holds the text "All rights reserved."

mif:licenseTerms (for MIF2) or mif:disclaimer (for MIF1) hold the DETAILS

The DETAILS are in text markup (per the MIF schemas) and use the xhtml 
  namespace for MIF2 and the MIF1 namespace for MIF1.  The Markup holds the
  license terms in a number of <p>, <b>, <i>, <a>, <ul>, and <li>etc. 
  elements, and has a SINGLE <code/> element.  The <code/> element holds 
  the same content licensed terms as the rest of the markup, but it
  is formatted as a text string that can included in the file as an XML 
  comment.

The Generator transforms are being modified to use these 
representations, as needed.
  