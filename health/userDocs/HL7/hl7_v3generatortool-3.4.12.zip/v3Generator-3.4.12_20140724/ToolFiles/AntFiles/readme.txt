This folder contains the subset of ANT files necessary to run the
HL7 Schema build process.  For more information on Ant, or to
download the complete Ant environment, go to:
http://ant.apache.org